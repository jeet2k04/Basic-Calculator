#include <gtk/gtk.h>


void
on_OK_clicked                          (GtkButton       *button,
                                        gpointer         user_data);

void
on_Cancel_clicked                      (GtkButton       *button,
                                        gpointer         user_data);
