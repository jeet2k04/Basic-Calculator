#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_OK_clicked                          (GtkButton       *button,
                                        gpointer         user_data)
{
	FILE *p=fopen("student.txt","a");
	char *roll,*name,*branch;
	GtkWidget *t1,*t2,*t3;
	t1=lookup_widget(GTK_WIDGET(button),"entry1");
	t2=lookup_widget(GTK_WIDGET(button),"entry2");
	t3=lookup_widget(GTK_WIDGET(button),"entry3");
	roll=gtk_entry_get_text(t1);
	name=gtk_entry_get_text(t2);
	branch=gtk_entry_get_text(t3);
	fprintf(p,"%s %s %s\n",roll,name,branch);

	gtk_entry_set_text(t1,"");
	gtk_entry_set_text(t2,"");
	gtk_entry_set_text(t3,"");

	gtk_widget_grab_focus(t1);
}
void
on_Cancel_clicked                          (GtkButton       *button,
	                                   gpointer         user_data)
{
	gtk_main_quit();
}



